package com.example.birinchi_dars

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
